/**
 * 
 */
package com.hundredms;
import java.util.ArrayList;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;


/**
 * @author Amit_Savyasachi
 *
 */
public class EndtoEnd100ms extends BrowserConfig  {
	UiElementsLocator ui=new UiElementsLocator();
	@Test
	public void EndToEndTest() throws InterruptedException {
		CreateaRoom();
		Join2PeersandVerify();
		SendMessageandVerify();					
	}
		
	public void CreateaRoom() {
		driver.findElement(ui.CreateRoomButton).click();
		driver.findElement(ui.RoomNameInputField).sendKeys("Ps123232");
		driver.findElement(ui.Username).sendKeys("Amit Savyasachi");
		driver.findElement(ui.Environment).sendKeys("qa-in");
		driver.findElement(ui.CreateRoomButton).click();
		try {
			 driver.findElement(ui.PromptPermission).click();	
			 
	      }
	      catch ( Exception ex) {
	         System.out.println("Executed on Chrome");
	      }
	      finally {
	         System. out. println( "Given Permission on FireFox") ;
	      }
			
	}
	public void Join2PeersandVerify() throws InterruptedException {
		 Thread.sleep(5000);
		 String code =driver.findElement(By.xpath("//p")).getText();
		 String code1= code.substring(code.indexOf("join")+5, code.indexOf("as"));
		 System.out.println(code1.trim());
		 driver.findElement(ui.JoinButton).click();
		
		 
		 Thread.sleep(5000);

		 String link = "window.open('https://prod.100ms.live/','_blank');";
			((JavascriptExecutor)driver).executeScript(link);
		
			ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		    driver.switchTo().window(tabs2.get(1));
		    try {
				 driver.findElement(ui.FFContinueinCB).click();	
		      }
		      catch ( Exception ex) {
		         System.out.println("Executed on Chrome");
		      }
		      finally {
		         System. out. println( "Continued on FireFox") ;
		      }
			driver.findElement(ui.JoinRoom).click();
			driver.findElement(ui.RoomID).sendKeys(code1.trim());
			driver.findElement(ui.Environment).sendKeys("qa-in");
			driver.findElement(ui.JoinRoom).click();
			 try {
				 driver.findElement(ui.PromptPermission).click();	
		      }
		      catch ( Exception ex) {
		         System.out.println("Executed on Chrome");
		      }
		      finally {
		         System. out. println( "Continued on FireFox") ;
		      }
			driver.findElement(ui.JoinButton).click();
		
	}
	public void SendMessageandVerify() {
		driver.findElement(ui.ChatButtonwidget).click();
		
		String Message="Hi From User 2";
		driver.findElement(ui.ChatBoxInput).sendKeys(Message);
		driver.findElement(ui.ChatEnterButton).click();
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(0));
		driver.findElement(ui.ChatButtonwidget).click();
		String Text =driver.findElement(By.xpath("//p[@class=\"pl\"]")).getText().trim();
		
		System.out.println(Text);
		
		if(Text.equalsIgnoreCase(Message)) {
			System.out.println("Chat Matched!" +Text+ "Was sent from User 2");
		}
		else {
			System.out.println("Chat Mis Matched");
		}	
		
	}
	@AfterTest
	public void Close() {
		driver.quit();
	}
		
}

