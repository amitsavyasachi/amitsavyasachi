/**
 * 
 */
package com.hundredms;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class Listeners implements ITestListener{
	
	 ExtentReports rep=ExtentReportTNG. GenerateReport();
	 ExtentTest test;
	public void onTestStart(ITestResult result) {
		test=rep.createTest(result.getMethod().getMethodName());
		
	}

	public void onTestSuccess(ITestResult result) {
		
		test.log(Status.PASS, "Successfully Executed");
		
	}

	public void onTestFailure(ITestResult result) {
		test.log(Status.FAIL, "Test Step Fail");
		result.getThrowable();
		
		
	}

	public void onTestSkipped(ITestResult result) {
		System.out.println("Test case Skipped");
		
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	public void onTestFailedWithTimeout(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	public void onStart(ITestContext context) {
		
		
	}

	public void onFinish(ITestContext context) {
		rep.flush();
		
	}
	
	

}
