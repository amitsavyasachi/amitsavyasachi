/**
 * 
 */
package com.hundredms;

import java.util.concurrent.TimeUnit;


/**
 * @author Lenovo
 *
 */
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

public class BrowserConfig {
	 static WebDriver driver;

		@Parameters("Browser")
		@BeforeTest
		public WebDriver Setup(String Browser) throws InterruptedException {
			
			if (Browser.equalsIgnoreCase("chrome")){
				System.setProperty("webdriver.chrome.driver","C:\\Users\\Lenovo\\Desktop\\chromedriver.exe");
				ChromeOptions options = new ChromeOptions();
			    options.addArguments("use-fake-device-for-media-stream");
			    options.addArguments("use-fake-ui-for-media-stream");
				driver=new ChromeDriver(options);
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
				driver.get("https://prod.100ms.live/");
				
			}
			else if(Browser.equalsIgnoreCase("firefox")) {
				System.setProperty("webdriver.gecko.driver","C:\\Users\\Lenovo\\Downloads\\geckodriver-v0.29.1-win32\\geckodriver.exe");
				FirefoxOptions options = new FirefoxOptions();
				options.addPreference("media.navigator.streams.fake", true);
				driver=new FirefoxDriver(options);
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
				driver.get("https://prod.100ms.live/");
				UiElementsLocator ui=new UiElementsLocator();
				driver.findElement(ui.FFContinueinCB).click();
			}
			
			return driver;		
		}
		
}
