/**
 * 
 */
package com.hundredms;

import org.openqa.selenium.By;

/**
 * @author Lenovo
 * This class contains call the UI Identifers for the element which we want to interact on the webpage.
 */
public class UiElementsLocator {
	By CreateRoomButton=By.xpath("//button[contains(text(),'Create Room')]");
	By RoomNameInputField= By.xpath("//input[@placeholder='Room Name']");
	By Username =By.xpath("//input[@placeholder='Username']");
	By Role=By.xpath("//input[@placeholder='Role']");
	By Environment=By.xpath("//input[@placeholder='Environment (qa-in/staging-in/prod-in)']");
	By BackToHome= By.xpath("//button[contains(text(),\"Back to Home\")]");
	By JoinRoom=By.xpath("//button[contains(text(),'Join Room')]");
	By RoomID=By.xpath("//input[@placeholder='Room ID']");
	By JoinButton=By.xpath("//button[contains(text(),'Join')]");
	By ChatButtonwidget=By.xpath("//div[@class=\"pt-1\"]/span[contains(text(),'Chat')]");
	By ChatBoxInput=By.xpath("//div[@class=\"chat-input\"]/input[@placeholder=\"Please input message\"]");
	By ChatEnterButton=By.xpath("//div[@class=\"chat-input\"]//button");
	By FFContinueinCB=By.xpath("//button[contains(text(),'Continue in current browser')]");
	By PromptPermission=By.xpath("//button[contains(text(),'Prompt permission dialog')]");
}
