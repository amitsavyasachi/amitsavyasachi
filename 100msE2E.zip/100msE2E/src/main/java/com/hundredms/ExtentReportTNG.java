/**
 * 
 */
package com.hundredms;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReportTNG {
	
	static ExtentReports rep;
	public static  ExtentReports GenerateReport() {
		//Using two class in the Extent Report to configure and create report i.e ExtentSparkReporter(helper class) & ExtentReports
		String path=System.getProperty("user.dir")+"\\rep\\rep.html";
		ExtentSparkReporter report=new ExtentSparkReporter(path);
		report.config().setReportName("100ms Dry Run Report");
		report.config().setDocumentTitle("Test Report 100ms");
		
		rep=new ExtentReports();  //main class object
		rep.attachReporter(report);
		rep.setSystemInfo("Tester Name", "Amit Savyasachi");
		rep.getStats();
		return rep;
		
		
	}
}